package Assign2;
import java.io.*;
import java.net.*;

public class Client {
	
	DatagramPacket sendPacket, receivePacket;
	DatagramSocket sendReceiveSocket;
	
	public Client() {
		try {
			sendReceiveSocket = new DatagramSocket();
		} catch (SocketException se) {
			se.printStackTrace();
			System.exit(1);
		}
		// TODO Auto-generated constructor stub
	}
	
	public void sendAndReceive(Boolean type)
	{

		byte data[] = new byte[100];
		receivePacket = new DatagramPacket(data, data.length);
		
		String file = "test";
		String mode = "ocTEt";
		byte fileName[] = file.getBytes();
		byte modeByte[] = mode.getBytes();
		byte msg[] = new byte[4+fileName.length+modeByte.length];
		if (type)
		{
			msg[0] = 0b00;
			msg[1] = 0b01;
		}else {
			msg[0] = 0b00;
			msg[1] = 0b10;
		}
		for(int i = 2; i < msg.length;i++)
		{
			if(i < fileName.length+2) {
				msg[i] = fileName[i-2];
			}else if(i == fileName.length+2) {
				msg[i] = 0b0;
			}else if(i < 3+fileName.length+modeByte.length) {
				msg[i] = modeByte[i-(3+fileName.length)];
			}else {
				msg[i] = 0b0;
			}
		}
		
		
		System.out.print("Message in packet in bytes: ");
		for(int i = 0; i < msg.length;i++) {
			System.out.print(msg[i]);
		}
		System.out.println("");
		System.out.println("Message in String"+msg[0]+msg[1]+file+0+mode+0);

	   // Construct a datagram packet that is to be sent to a specified port 
	   // on a specified host.
	   // The arguments are:
	   //  msg - the message contained in the packet (the byte array)
	   //  msg.length - the length of the byte array
	   //  InetAddress.getLocalHost() - the Internet address of the 
	   //     destination host.
	   //     In this example, we want the destination to be the same as
	      //     the source (i.e., we want to run the client and server on the
	   //     same computer). InetAddress.getLocalHost() returns the Internet
	   //     address of the local host.
	   //  5000 - the destination port number on the destination host.
	   try {
		   sendPacket = new DatagramPacket(msg, msg.length,
				   InetAddress.getLocalHost(), 23);

		   System.out.println("Client: Sending packet:");
		   System.out.println("To host: " + sendPacket.getAddress());
		   System.out.println("Destination host port: " + sendPacket.getPort());
		   int len = sendPacket.getLength();
		   System.out.println("Length: " + len);
		   System.out.print("Containing: ");
		   System.out.println(new String(sendPacket.getData(),0,len)); // or could print "s"
		   
		   sendReceiveSocket.send(sendPacket);
		   System.out.println("Client: Packet sent.\n");
		   
		   sendReceiveSocket.receive(receivePacket);
		   // Process the received datagram.
		   System.out.println("Client: Packet received:");
		   System.out.println("From host: " + receivePacket.getAddress());
		   System.out.println("Host port: " + receivePacket.getPort());
		   len = receivePacket.getLength();
		   System.out.println("Length: " + len);
		   System.out.print("Containing: ");
		   
		   // Form a String from the byte array.
		   String received = new String(data,0,len);   
		   System.out.println(received);
			   
			   
		   } catch (UnknownHostException e) {
			   e.printStackTrace();
			   System.exit(1);
		   } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		   }
	}
	
	private void closeSocket() {
		// We're finished, so close the socket.
		sendReceiveSocket.close();
	}
	
	public static void main(String arg[]) {
		Client client = new Client();
		client.sendAndReceive(true);
		for (int i = 0; i <=5; i++)
		{
			if (i % 2 == 1) {
				client.sendAndReceive(true);
			}else {
				client.sendAndReceive(false);
			}
		}
		client.closeSocket();
	}
}

