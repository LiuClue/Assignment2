package Assign2;

import java.io.*;
import java.net.*;

public class IntermediateHost {


	DatagramPacket sendPacket, receivePacket;
	DatagramSocket sendReceiveSocket, receiveSocket;
	public IntermediateHost() {
		try {
	         sendReceiveSocket = new DatagramSocket();
	         receiveSocket = new DatagramSocket(23);
	      } catch (SocketException se) {
	         se.printStackTrace();
	         System.exit(1);
	      } 
	
	}
	public void receiveAndEcho()
	{
		// Construct a DatagramPacket for receiving packets up 
		// to 100 bytes long (the length of the byte array).

		byte data[] = new byte[100];
		receivePacket = new DatagramPacket(data, data.length);
		System.out.println("IntServer: Waiting for Packet.\n");

		// Block until a datagram packet is received from receiveSocket.
		try {        
			System.out.println("Waiting..."); // so we know we're waiting
			receiveSocket.receive(receivePacket);
		} catch (IOException e) {
			System.out.print("IO Exception: likely:");
			System.out.println("Receive Socket Timed Out.\n" + e);
			e.printStackTrace();
			System.exit(1);
		}

		// Process the received datagram.
		System.out.println("IntServer: Packet received:");
		System.out.println("From host: " + receivePacket.getAddress());
		InetAddress clientAddress = receivePacket.getAddress();
		System.out.println("Host port: " + receivePacket.getPort());
		int clientPort = receivePacket.getPort();
		int len = receivePacket.getLength();
		System.out.println("Length: " + len);
		System.out.print("Containing: " );

		// Form a String from the byte array.

		System.out.print("Message in packet in bytes: ");
		for(int i = 0; i < data.length;i++) {
			System.out.print(data[i]);
		}
		String received = new String(data,0,len);   
		System.out.println("\n"+received + "\n");
		
		// Slow things down (wait 5 seconds)
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e ) {
			e.printStackTrace();
			System.exit(1);
		}
	 
		// Create a new datagram packet containing the string received from the client.	

		// Construct a datagram packet that is to be sent to a specified port 
		// on a specified host.
		// The arguments are:
		//  data - the packet data (a byte array). This is the packet data
		//         that was received from the client.
		//  receivePacket.getLength() - the length of the packet data.
		//    Since we are echoing the received packet, this is the length 
		//    of the received packet's data. 
		//    This value is <= data.length (the length of the byte array).
		//  receivePacket.getAddress() - the Internet address of the 
		//     destination host. Since we want to send a packet back to the 
		//     client, we extract the address of the machine where the
		//     client is running from the datagram that was sent to us by 
		//     the client.
		//  receivePacket.getPort() - the destination port number on the 
		//     destination host where the client is running. The client
		//     sends and receives datagrams through the same socket/port,
		//     so we extract the port that the client used to send us the
		//     datagram, and use that as the destination port for the echoed
		//     packet.

		try {
			sendPacket = new DatagramPacket(data, receivePacket.getLength(),
			                           InetAddress.getLocalHost(), 69);
		} catch (UnknownHostException e1) {
		   e1.printStackTrace();
		   System.exit(1);
		}

		System.out.println("IntServer: Sending packet:");
		System.out.println("To host: " + sendPacket.getAddress());
		System.out.println("Destination host port: " + sendPacket.getPort());
		len = sendPacket.getLength();
		System.out.println("Length: " + len);
		System.out.print("Containing: ");
		System.out.println(new String(sendPacket.getData(),0,len));
		// or (as we should be sending back the same thing)
		// System.out.println(received); 
		
		// Send the datagram packet to the client via the send socket. 
		try {
			sendReceiveSocket.send(sendPacket);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}

		System.out.println("IntServer: packet sent");
		
		System.out.println("IntServer: Waiting for Packet.\n");

		// Block until a datagram packet is received from receiveSocket.
		try {        
			System.out.println("Waiting..."); // so we know we're waiting
			sendReceiveSocket.receive(receivePacket);
		} catch (IOException e) {
			System.out.print("IO Exception: likely:");
			System.out.println("Receive Socket Timed Out.\n" + e);
			e.printStackTrace();
			System.exit(1);
		}

		
		// Slow things down (wait 5 seconds)
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e ) {
			e.printStackTrace();
			System.exit(1);
		}
	 
		// Create a new datagram packet containing the string received from the client.	

		// Construct a datagram packet that is to be sent to a specified port 
		// on a specified host.
		// The arguments are:
		//  data - the packet data (a byte array). This is the packet data
		//         that was received from the client.
		//  receivePacket.getLength() - the length of the packet data.
		//    Since we are echoing the received packet, this is the length 
		//    of the received packet's data. 
		//    This value is <= data.length (the length of the byte array).
		//  receivePacket.getAddress() - the Internet address of the 
		//     destination host. Since we want to send a packet back to the 
		//     client, we extract the address of the machine where the
		//     client is running from the datagram that was sent to us by 
		//     the client.
		//  receivePacket.getPort() - the destination port number on the 
		//     destination host where the client is running. The client
		//     sends and receives datagrams through the same socket/port,
		//     so we extract the port that the client used to send us the
		//     datagram, and use that as the destination port for the echoed
		//     packet.

		sendPacket = new DatagramPacket(data, receivePacket.getLength(), clientAddress, clientPort);

		System.out.println("IntServer: Sending packet:");
		System.out.println("To host: " + sendPacket.getAddress());
		System.out.println("Destination host port: " + sendPacket.getPort());
		len = sendPacket.getLength();
		System.out.println("Length: " + len);
		System.out.print("Containing: ");
		System.out.println(new String(sendPacket.getData(),0,len));
		// or (as we should be sending back the same thing)
		// System.out.println(received); 
		
		// Send the datagram packet to the client via the send socket. 
		try {
			sendReceiveSocket.send(sendPacket);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}

		System.out.println("IntServer: packet sent");
	}
	
	public static void main(String args[])
	{
		IntermediateHost interHost = new IntermediateHost();
		while(true) {
			interHost.receiveAndEcho();
		}
	}
}
